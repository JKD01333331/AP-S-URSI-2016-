% Author: Zachary T Miers
% Last Modification (November 21, 2012)
% zachary.miers@eit.lth.se


% Matlab Temp Directory
Temp_save = 'C:\temp';

% Directory and Name of File to Be Evaluated
file_location = 'C:\Matlab_CMA\'; % Directory of file
file_name = 'Matlab_CMA_rec.stl';
Object_location = [file_location file_name]; % location of the object to solve


freqmin = 0.8e9; % Minimum Evaluation Frequency
freqmax = 1.2e9; % Maximum Evaluation Frequency
N_freq = 21; % Number of evalution points
frequency = 0.98e9; % field evaluation frequency


enable_plot_mesh = 1; %enable (1) or disable (0) mesh plot
enable_plot_eigenvalue = 1; %enable (1) or disable (0) eigenvalue plot
enable_plot_currents = 1; %enable (1) or disable (0) currents plot
Nearfield_views = 'all'; % Set which fields to plot 'off', 'all', 'Mag', 'Ex', ... etc
plot_2D_FF = 1;
Plot_3D_FF = 1;

Select_eigen_mode = 'nothing'; % 'nothing' for a list of eigen modes, 1 for lowest eigenvalue
set_y_axis_eigenvalue = [-30 30]; % set the scale in the y-axis in the eigen values plot

Linear_or_dB_currents = 0; %Plot currents in dB (0) or linear (1)

X_view_points_NF = [0 0.136]; % Set the x min and max view points [min max] or 'auto'
Y_view_points_NF = [0 0.066]; % Set the x min and max view points [min max] or 'auto'
Z_view_point_NF = 0.020; % Set the z view point [position] or 'auto'
set_xyz_axis_NF = 'auto'; % Set the xyz axis on plots [x y z], or 'auto'
aspect_ratio_NF = 'auto'; % spect ratio in [x y z] form, for 'auto'


Linear_or_dB_2DFF = 1; % set the plot scale dB(0), linear(1)
angle_step_size_3DFF = 10;


% Can use script to evaluate many different structures
Obj_num = 1;

% These are temparary save locations you need for seperate files
rwg1_save = [Temp_save '\mesh1-' num2str(Obj_num) '.mat']; 
rwg2_save = [Temp_save '\mesh2-' num2str(Obj_num) '.mat'];
Eigen_save = [Temp_save '\eigenmodes-' num2str(Obj_num) '.mat'];
currents_save = [Temp_save '\currents-' num2str(Obj_num) '.mat'];
currents_correlate = [Temp_save '\Currents_correlate-' num2str(Obj_num) '.mat'];
nearfields_save = [Temp_save '\nearfields-' num2str(Obj_num) '.mat'];
efield2_save = [Temp_save '\efield2-' num2str(Obj_num) '.mat'];
currents_correlate = [Temp_save '\Currents_correlate-' num2str(frequency/1e9)...
    '-' num2str(Select_eigen_mode) '.mat'];



%%%%%%%%%%%%%% Obtain RWG1 and RWG2 Files for Mesh %%%%%%%%%%%%%%
% Mesh information provides the total number of edges in your STL file if
% this is set to 0 it will not provide mesh information if it is set to 1
% it will provide mesh information
Mesh_infromation = 0;
% RWG1 - Please see help file more information
RWG1_script(Object_location, 'msh_mm', Temp_save, rwg1_save, ...
    Mesh_infromation,enable_plot_mesh);

RWG2_script(rwg1_save, rwg2_save);

%%%%%%%%%%%%%%%%%%%% Obtain Eigen Value Plot %%%%%%%%%%%%%%%%%%%%

% Plotting the Eigen values
%   For many more options see help file
eigenmode2_script(rwg2_save, Eigen_save, freqmin, freqmax, N_freq, ...
    enable_plot_eigenvalue, set_y_axis_eigenvalue);

%%%%%%%%%%%%%% Obtain Currents and Plot Currents %%%%%%%%%%%%%%%

% Obtain the currents with current2
%   For options see help file
currents_script(rwg2_save,currents_save,frequency,Select_eigen_mode);

% Plot the currents with RWG5
% See RWG5_script help file for more information
[X,Y,Z,C] = RWG5_script(rwg2_save, currents_save,...
    currents_correlate, enable_plot_currents, Linear_or_dB_currents);
view(-45,33);
% Enable the below to set tick values of currents plot
% axis_dem = [-0.1 66.1 -0.1 130.1 0 8.1];
% axis(axis_dem);
% set(gca,'FontSize',16); %
% set(gca,'ZTick',[8]);
% set(gca,'XTick',[0 33 66]);
% set(gca,'YTick',[65 130]);
% caxis([ -30 0 ]);


%%%%%%%%%%%%%%%%%%%%% Obtain Near Fields %%%%%%%%%%%%%%%%%%%%%%

% Obtain and plot the near fields 
Nearfield_views_calc = 'off'; % Set which fields to plot 'off', 'all', 'Mag', 'Ex', ... etc
aspect_ratio_NF_calc = 'auto'; % Set the aspect ratio for the plot figures
set_xyz_axis_NF_calc = 'auto'; % Set the axis for the plot figures
Nearfields_script(rwg2_save, currents_save,...
    X_view_points_NF, Y_view_points_NF, Z_view_point_NF, nearfields_save,...
    Nearfield_views_calc, aspect_ratio_NF_calc,set_xyz_axis_NF_calc);


% Plot any saved nearfields from previous Nearfields_script
% aspect_ratio = 'auto';
% Nearfield_views = 'all';
% daspect(aspect_ratio_NF);
Nearfield_plot(nearfields_save,Nearfield_views,aspect_ratio_NF,set_xyz_axis_NF);
daspect(aspect_ratio_NF);
axis equal

%%%%%%%%%%%%%%% Evaluate and Plot the Far Fields %%%%%%%%%%%%%%%

% Evaluate the far fields with efield2
radius = 1000;
efield2_script(rwg2_save, currents_save, efield2_save, plot_2D_FF, radius);



% Choose principle plane to plot
for count = 1:3
    if count == 1
        plot_axis = 'xy';
    elseif count == 2
        plot_axis = 'xz';
    elseif count == 3
        plot_axis = 'yz';
    end

    setaxis = [0 1];
    setlinecolor = 'b--';
    setaxis_tic = 30;
    setfontsize = 15;
    GainLogarithmic = efield3_script(rwg2_save, currents_save, efield2_save, ...
       plot_axis, Linear_or_dB_2DFF ,setaxis, setlinecolor,setaxis_tic,setfontsize);
   
end

if Plot_3D_FF == 1
    R = 100;
    E_out = efield3_Theta_Phi_3D(rwg2_save, currents_save, ...
    efield2_save,angle_step_size_3DFF,radius,Plot_3D_FF);
end