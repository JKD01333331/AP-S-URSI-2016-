function [E_out] = efield3_Theta_Phi_3D(rwg2_save, currents_save, ...
    efield2_save,angle_step_size,R,DoNotPlot)
% [E_out] = efield3_Theta_Phi_3D(rwg2_save, currents_save, ...
%     efield2_save,angle_step_size,R,DoNotPlot)
%
% Main Author: Copyright 2002 AEMM. Revision 2002/03/09 Chapter 2
% Author 2: Zachary T Miers
% Function Author: Zachary T Miers (April 28, 2014)
%
% Inputs:
%   rwg2_save - Location where rwg2 output file is located.
%   currents_save - Location where currents output file is located.
%   efield2_save - Location where efield2 output file is located.
%   angle_step_size - Increment step of farfield step in degrees
%   R - Radius in meters from cartesian origin (not structure origin)
%   
% Optional Inputs:
%   DoNotPlot - Set to 1 to disable plots; Default (0) Plots Enabled
%
% Outputs:
% 	E - E-field points
%       E_out(theta_E; phi_E; ET_total; E_Out_Theta; E_Out_Phi)
%   3D Graph of E-field
% 
% EFIELD3 3D Radiation patterns
%   Uses the mesh file from RWG2, mesh2.mat, and
%   the file containing surface current coefficients,
%   current.mat, from RWG4 as inputs.
%
%   Additionally uses the value of TotalPower saved 
%   in file gainpower.mat (script efield2.m)
%
%   The following parameters need to be specified:
%   
%   Radius of the circle (m)            R
%   angle seperation of each discretization points
%
%   Copyright 2002 AEMM. Revision 2002/03/11 
%   Chapter 3
% 
% Example 1 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   currents_save = 'C:\currents.mat';
%   efield2_save = 'C:\efield2_save.mat';
%   degstep = 10; %10 degree step resolution
%   DoNotPlot = 0; % if set to 1 nothing will be plotted
%   R = 100; %100 meters from cartesian origin (not structure origin)
%   E = efield3_script(rwg2_save, currents_save, efield2_save, ...
%       degstep,R);
% 
% File Dependencies before this file is run: RWG2 output file, and the
%           current output file, and efields2 output file
%
% File Dependencies within this file: point.m
%

tic;

if ~exist('DoNotPlot', 'var')
    DoNotPlot = 1;
end

%Load the data
load(rwg2_save);
load(currents_save);
load(efield2_save);

k=omega/c_;
K=j*k;

% locate all the rotation points to cover a sphere
theta_points = round(180/angle_step_size)+1;
phi_points = round(360/angle_step_size)+1;
count = 0;

for phi_step=1:phi_points
    for theta_step = 1:theta_points
        count = count + 1;

        phi_E(count) = deg2rad(angle_step_size*(phi_step-1));
        theta_E(count) = deg2rad(angle_step_size*(theta_step-1));
        
        phi(phi_step)=phi_E(count);
        theta(theta_step)=theta_E(count);

    end
end
clear count phi_step theta_step

% Rotate the entire structure and evaluate the E-field using point.m
count = 0;
for phi_step=1:phi_points
    for theta_step = 1:theta_points
        count = count + 1;
        ObservationPoint = [0, 0, R];

        for count_rotate = 1:length(Center)
            % the negitive value in the phi is so that the coordinates
            % match up with CST and FEKO.  This is not the same convension
            % as sph2cart.
            xyz2rotate = rotate_xyz(Center(:,count_rotate),-phi(phi_step)-pi,'z');
            Center_new(:,count_rotate) = rotate_xyz(xyz2rotate,theta(theta_step)-pi,'y');
        end
        
        for m=1:EdgesTotal
            Point1=Center_new(:,TrianglePlus(m));
            Point2=Center_new(:,TriangleMinus(m));
            DipoleCenter(:,m)=0.5*(Point1+Point2);
            DipoleMoment(:,m)=EdgeLength(m)*I(m)*(-Point1+Point2); 
        end
            
        [E1,H2]=point(ObservationPoint',eta_,K,DipoleMoment,DipoleCenter);
        clear ET
        % Sum all the E components to find the total E-field from the
        % dipole point sources
        ET=sum(E1,2); 
        HT=sum(H2,2);
        clear E1 H2
        
        % Theta is the X component of the E-Field
        E_abs_Theta(count) = abs(ET(1));
        % Phi is the Y component of the E-Field
        E_abs_Phi(count) = abs(ET(2));
        % Total power should be the vector length of theta plus phi
        ET_total(count) = sqrt(abs(ET(1))^2+abs(ET(2))^2);
        
        ET_R(count,:) = [real(ET(1)), real(ET(2)), real(ET(3))];
        ET_I(count,:) = [imag(ET(1)), imag(ET(2)),imag(ET(3))];

        E_Out_Theta(count) = real(ET(1)) + 1i*imag(ET(1));
        E_Out_Phi(count) = real(ET(2)) + 1i*imag(ET(2));
       
    end
end

% Check to see that the amount of perpendicular power is less than 1%
Max_E_Theta = max(ET_R(:,1));
Max_E_Phi = max(ET_R(:,2));
Max_E_Z = max(ET_R(:,3));
Perpendicular_Power = max([(Max_E_Z/Max_E_Theta), (Max_E_Z/Max_E_Phi)])*100;
if Perpendicular_Power > 1
    warning('Near field detected: %1.1f%% of the power is Perpendicular to the antenna',Perpendicular_Power);
end


% Save Variables to export from this script
E_out = [theta_E; phi_E; ET_total; E_Out_Theta; E_Out_Phi];

% Plot the Farfield Phi and Theta Data
if DoNotPlot == 1
    figure
    count_total = 0;
    clear x y z r X Y Z Rt
    for count_phi = 1:length(phi)
        for count_theta = 1:length(theta)
        count_total = count_total +1;
        [x(count_total),y(count_total),r(count_total)] = sph2cart(phi(count_phi),...
            theta(count_theta)+pi/2,...
            ET_total(count_total));
        end
    end
    
    count = 0;
    X = zeros(length(phi),length(theta))*NaN;
    Y = zeros(length(phi),length(theta))*NaN;
    Z = zeros(length(phi),length(theta))*NaN;
    Rt = zeros(length(phi),length(theta))*NaN;
    
    for count1 = 1:length(phi)
        for count2 = 1:length(theta)
            count = count + 1;
            X(count1, count2) = x(count);
            Y(count1, count2) = y(count);
            Z(count1, count2) = r(count);
            Rt(count1, count2) = ET_total(count);
        end
    end
    surf(X,Y,Z,Rt)
    axis equal
    % shading('interp')
    ylabel('Y')
    xlabel('X')
    zlabel('Z')
    
    
    
%     FarField_plot_3D(E_abs_Theta, theta_E-pi/2, phi_E, angle_step_size, 'E Theta');
%     figure
%     FarField_plot_3D(E_abs_Phi, theta_E-pi/2, phi_E, angle_step_size, 'E Phi');
end



