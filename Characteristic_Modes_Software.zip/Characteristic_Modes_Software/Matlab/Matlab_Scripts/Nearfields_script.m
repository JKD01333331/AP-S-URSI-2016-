function [Run_time] = Nearfields_script(rwg2_save, currents_save,...
    X_view_points, Y_view_points, Z_view_point, nearfields_save,...
    Nearfield_views, aspect_ratio,set_xyz_axis)
% [Run_time] = Nearfields_script(rwg2_save,currents_save,nearfields_save...
%               ,Nearfield_views,aspect_ratio,set_xyz_axis)
%
% Main Author: Copyright 2002 AEMM. Revision 2002/03/09 Chapter 2
% Author 2: Buon Kiong Lau
% Author 3: Hui Li
% Author 4: Zachary T Miers
% Function Author: Zachary T Miers (January 17, 2013)
%
% Inputs:
%   rwg2_save - Location where rwg2 output file is located.
%   currents_save - Location where currents output file is located.
% Optional inputs:
%   X_view_points - set the x and minimum and maximum [min max] of the
%       area to be evaluated, 'auto' locates the minimum and maximum x
%       values of the structures and uses these points.
%   Y_view_points - set the y and minimum and maximum [min max] of the
%       area to be evaluated, 'auto' locates the minimum and maximum x
%       values of the structures and uses these points.
%   Z_view_point - View point for where the nearfields are calculated from
%       'auto' locates the top of the structure + 0.01 and sets this to the
%       view point
%   nearfields_save - 'Do_Not_Save' will skip this variable otherwise all
%       calculated variables will be saved to a file, this file is used by
%       Nearfield_plot.m
%   Nearfield_views - plot specific views: all plots on - 'all', magnitude
%       - 'mag', all H plots - 'H', all E plots - 'E', do not plot - 'off',
%       many more are avalible see help Nearfield_view_lookup
%   aspect_ratio - input required aspect ratio in [x y z] form, for auto
%       aspect ratio 'off' or 'auto' will set default values
%   set_xyz_axis - Set the xyz axis on plots [x y z], To automatically set
%       the axis use 'auto'
%
% Outputs:
% 	Runtime: time it takes for the program to run
% Optional outputs:
%   Nearfield save file
% 
% EFIELD1 Radiated/scattered field at a point
%   The point is outside the metal surface
%   Uses the mesh file from RWG2, mesh2.mat, and
%   the file containing surface current coefficients,
%   current.mat, from RWG4 as inputs.
%
%
%   Copyright 2002 AEMM. Revision 2002/03/11 
%   Chapter 3
% 
% Example 1 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   currents_save = 'C:\currents.mat';
%   nearfields_script(rwg2_save,currents_save)
% 
% Example 2 of how to run this file:
%   X_view_points = 'auto';
%	Y_view_points = 'auto';
%	Z_view_point = 'auto';
%   Nearfield_views = 'Mag';
%   aspect_ratio = 'off';
%   set_xyz_axis = 'auto';
%   Nearfields_script(rwg2_save, currents_save,...
%       X_view_points, Y_view_points, Z_view_point, nearfields_save,...
%       Nearfield_views, aspect_ratio,set_xyz_axis)
% 
% Example 3 of how to run this file:
%   X_view_points = [0 0.12];
%	Y_view_points = [0 0.06];
%	Z_view_point = 0.015;
%   Nearfield_views = 'all';
%   aspect_ratio = [0.12 0.12 30];
%   set_xyz_axis = [0 0.12 0 0.06 -15 0];
%   Nearfields_script(rwg2_save, currents_save,...
%       X_view_points, Y_view_points, Z_view_point, nearfields_save,...
%       Nearfield_views, aspect_ratio,set_xyz_axis)
% 
% File Dependencies before this file is run: RWG2 output file, and the
%                                            current output file
%
% File Dependencies within this file: point.m Nearfield_view_lookup.m
%
tic;

h = waitbar(0,'Near Fields are Being Calculated, Please wait...');

if ~exist('X_view_points', 'var')
    X_view_points = 'auto';
end
if ~exist('Y_view_points', 'var')
    Y_view_points = 'auto';
end
if ~exist('Z_view_point', 'var')
    Z_view_point = 'auto';
end
if ~exist('nearfields_save', 'var')
    nearfields_save = 'Do_Not_Save';
end
if ~exist('Nearfield_views', 'var')
    Nearfield_views = 'all';
end
if ~exist('aspect_ratio', 'var')
    aspect_ratio = 'off';
end
if ~exist('set_xyz_axis', 'var')
    set_xyz_axis = 'auto';
end

Nearfield_views = Nearfield_view_lookup(Nearfield_views); % locates the
                    % plots that were requested

%Load the data
load(rwg2_save);
load(currents_save);

k=omega/c_;
K=j*k;

for m=1:EdgesTotal
    Point1=Center(:,TrianglePlus(m));
    Point2=Center(:,TriangleMinus(m));
    DipoleCenter(:,m)=0.5*(Point1+Point2);
    DipoleMoment(:,m)=EdgeLength(m)*I(m)*(-Point1+Point2); 
end

Steps_x = 241;
Steps_y = 121;

% Setting up the view points
if strcmpi(X_view_points,'auto') == 1
    x_min = min(p(1,:));
    x_max = max(p(1,:))+0.001;
else
    x_min = min(X_view_points);
    x_max = max(X_view_points);
end

if strcmpi(Y_view_points,'auto') == 1
    y_min = min(p(2,:));
    y_max = max(p(2,:))+0.001;
else
    y_min = min(Y_view_points);
    y_max = max(Y_view_points);
end

if strcmpi(Z_view_point,'auto') == 1
    z_view = max(p(3,:))+0.015;
else
    z_view = Z_view_point;
end

% Calculating the fields
for p=1:Steps_x
    waitbar(p / (Steps_x+1));
    II=0+((x_max-x_min)/(Steps_x-1))*p; %xdim
    for q=1:Steps_y
        JJ=y_min+((y_max-y_min)/(Steps_y-1))*q; % be careful of the coodinates here! ydim
    F=[II; JJ; z_view]; %zdim
[E1,H1]=point(F,eta_,K,DipoleMoment,DipoleCenter);
EField=sum(E1,2);
Hfield=sum(H1,2);
Poynting(p,q,:)=0.5*real(cross(EField,conj(Hfield)));

E(p,q,:)=EField;
H(p,q,:)=Hfield;
EE(p,q)=sqrtm(abs(E(p,q,1))^2+abs(E(p,q,2))^2+abs(E(p,q,3))^2);
EEx(p,q)=sqrtm(abs(E(p,q,1))^2);
EEy(p,q)=sqrtm(abs(E(p,q,2))^2);
EEz(p,q)=sqrtm(abs(E(p,q,3))^2);
HH(p,q)=sqrtm(abs(H(p,q,1))^2+abs(H(p,q,2))^2+abs(H(p,q,3))^2);
HHx(p,q)=sqrtm(abs(H(p,q,1))^2);
HHy(p,q)=sqrtm(abs(H(p,q,2))^2);
HHz(p,q)=sqrtm(abs(H(p,q,3))^2);
% poynting(p,q)=sqrtm(abs(Poynting(p,q,1))^2+abs(Poynting(p,q,2))^2+abs(Poynting(p,q,3))^2);
    end
end

waitbar(1);

EExdB=10*log10(EEx./max(EE(:)));
EEydB=10*log10(EEy./max(EE(:)));
EEzdB=10*log10(EEz./max(EE(:)));
EE=EE./max(EE(:));
EEdB=10*log10(EE);

HHxdB=10*log10(HHx./max(HH(:)));
HHydB=10*log10(HHy./max(HH(:)));
HHzdB=10*log10(HHz./max(HH(:)));
% mu0=4*pi*1e-7;
% epsilon0=8.85e-12;
HH=HH./max(HH(:));
% HH=sqrt(mu0/epsilon0).*HH;
HHdB=10*log10(HH);

p=x_min:((x_max-x_min)/(Steps_x-1)):x_max;
q=y_min:((y_max-y_min)/(Steps_y-1)):y_max;

close(h)

[pp,qq]=meshgrid(p,q);

% index points of plot
Em = 1;
Hm = 2;
Hx = 3;
Hy = 4;
Hz = 5;
Ex = 6;
Ey = 7;
Ez = 8;

% plot fields
if Nearfield_views(Em) == 1 % Magnitude Plot of E-field
    figure
    mesh(pp,qq,EEdB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(mm)');
    ylabel('(mm)');
    zlabel('E ');
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        daspect(aspect_ratio);
    end
end

if Nearfield_views(Hm) == 1 % Magnitude Plot of H-field
    figure
    mesh(pp,qq,HHdB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(mm)');
    ylabel('(mm)');
    zlabel('H ');
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        daspect(aspect_ratio);
    end
end

% if Nearfield_views(Poy) == 1 % Plot of Poynting vector
%     % mesh(pp,qq,poynting.');
%     % axis tight;
%     % if strcmpi(set_xyz_axis,'auto') == 0
%     %     axis(set_xyz_axis)
%     % end
%     % Xlabel('(mm)');
%     % Ylabel('(mm)');
%     % Zlabel('Poynting');
%     % if (strcmpi(aspect_ratio,'off') == 0)||(strcmpi(aspect_ratio,'auto') == 0)
%     %     daspect(aspect_ratio);
%     % end
% end

if Nearfield_views(Hx) == 1 % Plot of H-field x component
    figure
    mesh(pp,qq,HHxdB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(m)');
    ylabel('(m)');
    zlabel('Hx (dB)');
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        daspect(aspect_ratio);
    end
end

if Nearfield_views(Hy) == 1 % Plot of H-field y component
    figure
    mesh(pp,qq,HHydB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(m)');
    ylabel('(m)');
    zlabel('Hy (dB)');
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        daspect(aspect_ratio);
    end
end

if Nearfield_views(Hz) == 1 % Plot of H-field z component
    figure
    mesh(pp,qq,HHzdB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(m)');
    ylabel('(m)');
    zlabel('Hz (dB)');
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        daspect(aspect_ratio);
    end
end

if Nearfield_views(Ex) == 1 % Plot of E-field x component
    figure
    mesh(pp,qq,EExdB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(m)');
    ylabel('(m)');
    zlabel('Ex (dB)');
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        daspect(aspect_ratio);
    end
end

if Nearfield_views(Ey) == 1 % Plot of E-field y component
    figure
    mesh(pp,qq,EEydB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(m)');
    ylabel('(m)');
    zlabel('Ey (dB)');
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        daspect(aspect_ratio);
    end
end

if Nearfield_views(Ez) == 1 % Plot of E-field z component
    figure
    mesh(pp,qq,EEzdB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(m)');
    ylabel('(m)');
    zlabel('Ez (dB)');
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        daspect(aspect_ratio);
    end
end


% save fields
if strcmpi(nearfields_save,'Do_Not_Save') == 0 % not a necessary save
    save(nearfields_save, 'p','q','pp','qq','EEdB','HHdB','HHxdB',...
    'HHydB','HHzdB','EExdB','EEydB','EEzdB','Poynting');
end

Run_time = toc;