function [Run_time] = eigenmode2_script(rwg2_save,Eigen_save,freqmin,freqmax,N_freq,enable_plot,set_y_axis)
% [Run_time] = eigenmode2_script(rwg2_save, Eigen_save, freqmin, ...
%               freqmax,N_freq, enable_plot, set_y_axis)
%
% Main Author: Copyright 2002 AEMM. Revision 2002/03/09 Chapter 2
% Author 2: Buon Kiong Lau
% Author 3: Hui Li
% Author 4: Zachary T Miers
% Function Author: Zachary T Miers (January 14, 2013)
% 
% 
% Inputs:
%   rwg2_save - Location where rwg2 output file is located.
%   Eigen_save - Location to save the output filse for this script
%   freqmin - minimum frequency for which to evaluate the eigen modes
%   freqmax - maximum frequency for which to evaluate the eigen modes
%   N_freq - number of frequency points to calculate
% Optional input parameters:
%   enable_plot - Set to 1 to plot data, 0 to disable plots (default is 1)
%   set_y_axis - Y-axis plot scale (default set to [-40 40])
%
% Script Outputs:
%     runtime - The amount of time it took the program to run to completion
% RWG3-eignemode2 Calculates the impedance matrix using function IMPMET
%   Uses the mesh file from RWG2, mesh2.mat, as an input.
%
%   The following parameters need to be specified prior to 
%   calculations:
%   
%   Frequency (Hz)                  f
%   Dielectric constant (SI)        epsilon_
%   Magnetic permeability (SI)      mu_
%
%   Copyright 2002 AEMM. Revision 2002/03/11 
%   Chapter 2
% 
% Example 1 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   Eigen_save = 'C:\eigenmodes.mat';
%   freqmin = 1e9;
%   freqmax = 2e9;
%   N_freq = 30;
%   eigenmode2_script(rwg2_save,Eigen_save,freqmin,freqmax,N_freq);
% 
% Example 2 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   Eigen_save = 'C:\eigenmodes.mat';
%   enable_plot = 1;
%   set_y_axis = [-10 10];
%   N_freq = 30;
%   freqmin = 1e9;
%   freqmax = 2e9;
%   eigenmode2_script(rwg2_save,Eigen_save,freqmin,freqmax,N_freq,enable_plot,set_y_axis)
% 
% File Dependencies before this file is run: RWG2 output file
%
% File Dependencies within this file: impmet.m
%

if ~exist('enable_plot', 'var')
    enable_plot = 1;
end

h = waitbar(0,'Eigen Values are Being Calculated, Please wait...');

%Load the data
load(rwg2_save);

% freqmin = 0.7e9;
% freqmax = 1e9;

% % % % % % % % % % % % % % % % Index=4;
N=N_freq;
freq = linspace(freqmin,freqmax,N);
%EM parameters (f=3e8 means that f=300 MHz)
for n=1:N
    %     clc
    waitbar(n / (N+1));
    f = freq(n);
    epsilon_    =8.854e-012;
    mu_         =1.257e-006;
    %Speed of light
    c_=1/sqrt(epsilon_*mu_);
    %Free-space impedance 
    eta_=sqrt(mu_/epsilon_);

    %Contemporary variables - introduced to speed up 
    %the impedance matrix calculation
    omega       =2*pi*f;                                            
    k           =omega/c_;
    K           =j*k;
    Constant1   =mu_/(4*pi);
    Constant2   =1/(j*4*pi*omega*epsilon_);
    Factor      =1/9;    

    FactorA=Factor*(j*omega*EdgeLength/4)*Constant1;
    FactorFi =Factor*EdgeLength*Constant2;

    for m=1:EdgesTotal
        RHO_P(:,:,m)=repmat(RHO_Plus(:,m),[1 9]);   %[3 9 EdgesTotal]
        RHO_M(:,:,m)=repmat(RHO_Minus(:,m),[1 9]);  %[3 9 EdgesTotal]
    end
    FactorA=FactorA.';
    FactorFi=FactorFi.';

    %Impedance matrix Z
    tic; %start timer

    Z=  impmet( EdgesTotal,TrianglesTotal,...
                EdgeLength,K,...
                Center,Center_,...
                TrianglePlus,TriangleMinus,...
                RHO_P,RHO_M,...
                RHO__Plus,RHO__Minus,...
                FactorA,FactorFi);
    % % make the impedance matrix symetric
    %          Z1=triu(Z);
    %          Z2=Z1+Z1.';
    %          Z3=diag(Z2)./2;
    %          Z4=diag(Z3);
    %          ZZ=Z2-Z4;
    Z1=Z+Z.';
    ZZ=Z1./2;


            R=real(ZZ);
            X=imag(ZZ);
    %         [J(:,:,n),D(:,:,n)]=eig(X(:,:,n),R(:,:,n));
    %         DD(:,n)=diag(D(:,:,n));
    [V, D]=eig(R);
    DD1=diag(D);
    % range the eigenvalue from large to small
    [DD2,IJ]=sort(DD1,1,'descend');
    %range the eigenvedtor accordingly
    for jj=1:EdgesTotal
        V1(:,jj)=V(:,IJ(jj));
    end
    %make the eigen value which is too small zero
    for ii=1:EdgesTotal
        if DD2(ii)<max(DD2)*0.001
            DD2(ii)=0;
        end
    end
    D1=diag(DD2);
    r=rank(D1);
    D11=zeros(EdgesTotal);
    % D11=zeros(9,9,n);
    D11(1:r,1:r)=D1(1:r,1:r);
    % D12(:,:,n)=D1(1:r,r+1:EdgesTotal,n);
    % D21(:,:,n)=D12(:,:,n).';
    % D22(:,:,n)=D1(r1:EdgesTotal,r+1:EdgesTotal,n);
    D2(1:r,1:r)=sqrtm(D11(1:r,1:r));
    A=V1.'*X*V1;
    A11(1:r,1:r)=A(1:r,1:r);
    A12(1:r,1:EdgesTotal-r)=A(1:r,r+1:EdgesTotal);
    A21(1:EdgesTotal-r,1:r)=A12(1:r,1:EdgesTotal-r).';
    A22(1:EdgesTotal-r,1:EdgesTotal-r)=A(r+1:EdgesTotal,r+1:EdgesTotal);
    B(1:r,1:r)=inv(D2(1:r,1:r))*(A11(1:r,1:r)-A12(1:r,1:EdgesTotal-r)*inv(A22(1:EdgesTotal-r,1:EdgesTotal-r))*A21(1:EdgesTotal-r,1:r))*inv(D2(1:r,1:r));
    B1{n}=eig(B(1:r,1:r));
    B1_sort{n} = IJ;
    % B2{n}=abs(1./(1+j*B1{n}));
    % B2{n}=180-atan(B1{n})*180/pi;
    % B3{n}=abs(1/(1+j*B1{n}));
    % plot(f/1e9,B1{n},'k.');
    % hold on
end
%Plotting Characteristic Modes
if enable_plot >= 1
    figure
    for n=1:N_freq
        plot(freq(n)/1e9,B1{n},'k.');
        hold on
    end
%     Yvalue=zeros(1,N);
%     Yvalue(:,:)=0;
%     f = linspace(freqmin,freqmax,N);
%     plot(f,Yvalue,'r')
    hold off
    if ~exist('set_y_axis', 'var')
        set_y_axis = [-40 40];
    end
    axis([[freqmin/1e9,freqmax/1e9] set_y_axis])
    title('Characteristic Modes')
    xlabel('Frequency (GHz)')
    ylabel('\lambda')
    hold off; %this was after the end
end
%Plotting Modal Significance
if enable_plot >= 2
    figure
    for n=1:N_freq
        plot(freq(n)/1e9,1./(1+abs(B1{n})),'k.');
        hold on
    end
%     Yvalue=zeros(1,N);
%     Yvalue(:,:)=0;
%     f = linspace(freqmin,freqmax,N);
%     plot(f,Yvalue,'r')
    hold off
    
    axis([freqmin/1e9 freqmax/1e9 0 1])
    title('Modal Significance')
    xlabel('Frequency (GHz)')
    ylabel('Modal Significance')
    hold off; %this was after the end
end
if enable_plot >= 3
    figure
    for n=1:N_freq
        plot(freq(n)/1e9,abs(atan(B1{n})),'k.');
        hold on
    end
%     Yvalue=zeros(1,N);
%     Yvalue(:,:)=0;
%     f = linspace(freqmin,freqmax,N);
%     plot(f,Yvalue,'r')
    title('Characteristic Angles')
    xlabel('Frequency (GHz)')
    ylabel('\lambda')
    hold off; %this was after the end
end
Run_time = toc; %elapsed time
waitbar(n / (N+1));
%Save result
save(Eigen_save, 'f','omega','mu_','epsilon_','c_', 'eta_','Z', 'freq', 'B1', 'B1_sort');
close(h) 

