function [X,Y,Z,C] = RWG5_script(rwg2_save,currents_save,...
    currents_correlate,enable_plot,dBorLin)
% [X,Y,Z,C] = RWG5_script(rwg2_save,currents_save,color_scale_min,...
%                           color_scale_max,dBorLin)
%
% Main Author: Copyright 2002 AEMM. Revision 2002/03/09 Chapter 2
% Author 2: Zachary T Miers (Corrilation and Save author)
% Author 3: Buon Kiong Lau
% Author 4: Hui Li
% Function Author: Zachary T Miers (January 14, 2013)
%
% Inputs:
%   rwg2_save - Location where rwg2 output file is located.
%   currents_save - Location where currents output file is located.
% Optional inputs:
%   dBorLin - sets the plot to linear scale or decible scale. (0 - default)
%       sets the system to decible scale as is standard in RWG5 (1) sets 
%       the scale to linear scale
%   enable_plot if 1 plots are enabled if 0 plots are disabled (default 1)
%
% Outputs:
% 	X - triangle point locations in x axis
%   Y - triangle point locations in y axis
%   Z - triangle point locations in z axis
%   C - Color scale produced from CurrentNorm1 or CurrentNorm2
% Optional outputs:
%   CurrentNorm_control - if this output is added to the list of outputs
%       CurrentNorm_control displays the min and max values the are graphed
% 
%RWG5 Visualizes the surface current magnitude 
%   Uses the mesh file from RWG2, mesh2.mat, and
%   the file containing surface current coefficients,
%   current.mat, from RWG4 as inputs.
%
%   Copyright 2002 AEMM. Revision 2002/03/05 
%   Chapter 2
%
% Example 1 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   currents_save = 'C:\currents.mat';
%   [X,Y,Z,C] = RWG5_script(rwg2_save,currents_save);
% 
% Example 2 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   currents_save = 'C:\currents.mat';
%   absolute_min_no_less_than = 'min';
%   absolute_max_no_more_than = 'max';
%   Decible_Plot = 1; % D
%   [X,Y,Z,C] = RWG5_script(rwg2_save,currents_save,...
%       absolute_min_no_less_than,absolute_max_no_more_than,Decible_Plot);
%
% Example 3 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   currents_save = 'C:\currents.mat';
%   absolute_min_no_less_than = 0.2; % sets values less than 0.2 to 0.2
%   absolute_max_no_more_than = 0.7; % sets values greater than 0.7 to 0.7
%   Linear_Plot = 0;
%   [X,Y,Z,C] = RWG5_script(rwg2_save,currents_save,...
%       absolute_min_no_less_than,absolute_max_no_more_than,Linear_Plot);
% 
% File Dependencies before this file is run: RWG2 output file, and the
%                                            current output file
%
% File Dependencies within this file: NONE
%

% Updates 
% August 2013 Zachary Miers
% Basic saves for Correlation
%
% September 2013 Zachary Miers
% Updates to Corrilation and plotting
%
% October 2013 Zachary Miers
% Updates to axis on plotting and color scales
%
% November 2014  Zachary Miers
% Further saves and updates to general code for Correlation analysis

if ~exist('dBorLin', 'var')
    dBorLin = 0; % linear = 1 dB = 0;
end

if ~exist('enable_plot', 'var')
    enable_plot = 1;
end

%load the data
load(rwg2_save);
load(currents_save);

Index=find(t(4,:)<=1);
Triangles=length(Index);

%Find the current density for every triangle
for k=1:Triangles
    i=[0 0 0]';
    for m=1:EdgesTotal
        IE=I(m)*EdgeLength(m);
        if(TrianglePlus(m)==k)
            i=i+IE*RHO_Plus(:,m)/(2*Area(TrianglePlus(m)));
        end
        if(TriangleMinus(m)==k)
            i=i+IE*RHO_Minus(:,m)/(2*Area(TriangleMinus(m)));
        end
    end
    CurrentNorm(k)=abs(norm(i));
end

Jmax=max(CurrentNorm);
MaxCurrent=strcat(num2str(Jmax),'[A/m]'); % turn on to see max current
CurrentNorm1=CurrentNorm/max(CurrentNorm);
% CurrentNorm1=CurrentNorm/6.7016;
CurrentNorm2=10*log10(CurrentNorm1);
for m=1:Triangles
    N=t(1:3,m);
    X(1:3,m)=[p(1,N)]';
    Y(1:3,m)=[p(2,N)]';
    Z(1:3,m)=[p(3,N)]';      
end

% C=repmat(CurrentNorm1,3,1);
CurrentNorm1_control = [min(CurrentNorm1) max(CurrentNorm1)];
CurrentNorm2_control = [min(CurrentNorm2) max(CurrentNorm2)];

CurrentNorm_control = CurrentNorm1_control;
C_linear = repmat(CurrentNorm1,3,1);
C_linear_sum = sum(sum(C_linear));

CurrentNorm_control = CurrentNorm2_control;
C_dB=repmat(CurrentNorm2,3,1);       
% Setting the plot axis to linear mode
if dBorLin == 1 % linear = 1 dB = 0;
C = C_linear;
% Setting the plot axis to dB mode
else % linear = 1 dB = 0;
C = C_dB;
end

% Plot the values choosen in mm scale
X_mm = X*1000;
Y_mm = Y*1000;
Z_mm = Z*1000;

if enable_plot == 1
    figure
    h=fill3(X_mm, Y_mm, Z_mm, C); %linear scale
    colormap;
    colorbar;
%     caxis([ cmin cmax ])
end
    axis('equal');
save(currents_correlate, 'X_mm','Y_mm','Z_mm','C_linear','C_dB',...
    'C_linear_sum','Selected_eigen_mode','Selected_Eigen_value');
set(gca, 'visible', 'off'); 
% daspect([1,1,1000])
% rotate3d
