function [Nearfield_views] = Nearfield_view_lookup(Nearfield_view_input)
% [Nearfield_views] = Nearfield_view_lookup(Nearfield_view_input)
%
% Main Author: Copyright 2013 Zachary Thomas Miers (January 17, 2013)
% Function Author: Zachary T Miers (January 14, 2013)
%
% Inputs:
%   Nearfield_view_input - Can take on values as defined:
%           - 'all' : Outputs all graphs Exyz,Hxyz, Mag E, Mag H
%           - 'mag' : Outpus only Mag E and Mag H
%           - 'Emag' : Outputs only Mag E
%           - 'Hmag' : Outputs only Mag H
%           - 'H' : Outputs all the H fields
%           - 'E' : Outputs all the E fields
%           - 'x' : Outputs H in x direction and E in x direction
%           - 'y' : Outputs H in y direction and E in y direction
%           - 'z' : Outputs H in z direction and E in z direction
%           - 'Ex' : Outputs E in x direction
%           - 'Ey' : Outputs E in y direction
%           - 'Ez' : Outputs E in z direction
%           - 'Hx' : Outputs H in x direction
%           - 'Hy' : Outputs H in y direction
%           - 'Hz' : Outputs H in z direction
%           - 'xy' : Outputs E and H in x and y directions
%           - 'xy' : Outputs E and H in x and z directions
%           - 'yz' : Outputs E and H in y and z directions
%           - 'Exy' : Outputs E in x and y directions
%           - 'Exy' : Outputs E in x and z directions
%           - 'Eyz' : Outputs E in y and z directions
%           - 'Hxy' : Outputs H in x and y directions
%           - 'Hxy' : Outputs H in x and z directions
%           - 'Hyz' : Outputs H in y and z directions
%
% Outputs:
% 	Nearfield_views - vector that defines which graph to print in
%       nearfields_script.m
% Example: Plot_views = Nearfield_view_lookup('all')
% 

Em = 0;
Hm = 0;
Hx = 0;
Hy = 0;
Hz = 0;
Ex = 0;
Ey = 0;
Ez = 0;
if strcmpi(Nearfield_view_input,'off') == 1
    1;
elseif strcmpi(Nearfield_view_input,'all') == 1
    Em = 1;
    Hm = 1;
    Hx = 1;
    Hy = 1;
    Hz = 1;
    Ex = 1;
    Ey = 1;
    Ez = 1;
elseif strcmpi(Nearfield_view_input,'mag') == 1
    Em = 1;
    Hm = 1;
elseif strcmpi(Nearfield_view_input,'Emag') == 1
    Em = 1;
elseif strcmpi(Nearfield_view_input,'Hmag') == 1
    Hm = 1;
elseif strcmpi(Nearfield_view_input,'H') == 1
    Hm = 1;
    Hx = 1;
    Hy = 1;
    Hz = 1;
elseif strcmpi(Nearfield_view_input,'E') == 1
    Em = 1;
    Ex = 1;
    Ey = 1;
    Ez = 1;
elseif strcmpi(Nearfield_view_input,'x') == 1
    Hx = 1;
    Ex = 1;
elseif strcmpi(Nearfield_view_input,'y') == 1
    Hy = 1;
    Ey = 1;
elseif strcmpi(Nearfield_view_input,'z') == 1
    Hz = 1;
    Ez = 1;
elseif strcmpi(Nearfield_view_input,'Ex') == 1
    Ex = 1;
elseif strcmpi(Nearfield_view_input,'Ey') == 1
    Ey = 1;
elseif strcmpi(Nearfield_view_input,'Ez') == 1
    Ez = 1;
elseif strcmpi(Nearfield_view_input,'Hx') == 1
    Hx = 1;
elseif strcmpi(Nearfield_view_input,'Hy') == 1
    Hy = 1;
elseif strcmpi(Nearfield_view_input,'Hz') == 1
    Hz = 1;
elseif strcmpi(Nearfield_view_input,'xy') == 1
    Hx = 1;
    Ex = 1;
    Hy = 1;
    Ey = 1;
elseif strcmpi(Nearfield_view_input,'xz') == 1
    Hx = 1;
    Ex = 1;
    Hz = 1;
    Ez = 1;
elseif strcmpi(Nearfield_view_input,'yz') == 1
    Hy = 1;
    Ey = 1;
    Hz = 1;
    Ez = 1;
elseif strcmpi(Nearfield_view_input,'Exy') == 1
    Ex = 1;
    Ey = 1;
elseif strcmpi(Nearfield_view_input,'Exz') == 1
    Ex = 1;
    Ez = 1;
elseif strcmpi(Nearfield_view_input,'Eyz') == 1
    Ey = 1;
    Ez = 1;
elseif strcmpi(Nearfield_view_input,'Hxy') == 1
    Hx = 1;
    Hy = 1;
elseif strcmpi(Nearfield_view_input,'Hxz') == 1
    Hx = 1;
    Hz = 1;
elseif strcmpi(Nearfield_view_input,'Hyz') == 1
    Hy = 1;
    Hz = 1;
else
    warning('"Nearfield_view_input" not recognized');
end

Nearfield_views = [Em,Hm,Hx,Hy,Hz,Ex,Ey,Ez];