function [Power_and_gain] = efield2_script(rwg2_save, currents_save, ...
    efield2_save, plot_on, radius)
% [Power_and_gain] = efield2_script(rwg2_save, currents_save, ...
%     efield2_save, radius)
%
% Main Author: Copyright 2002 AEMM. Revision 2002/03/09 Chapter 2
% Author 2: Buon Kiong Lau
% Author 3: Hui Li
% Author 4: Zachary T Miers
% Function Author: Zachary T Miers (January 17, 2013)
%
% Inputs:
%   rwg2_save - Location where rwg2 output file is located.
%   currents_save - Location where currents output file is located.
%   efield2_save - Location to save the output currents output file
% 
% Optional inputs:
%   plot_on - plots sphere if set to 0 default is 1
%   radius - sphere radius default is 100m
%
% Outputs:
% 	Power_and_gain - TotalPower, GainLogarithmic, GainLinear
% 
%EFIELD2 Radiated/scattered field over a large sphere
%   Uses the mesh file from RWG2, mesh2.mat, and
%   the file containing surface current coefficients,
%   current.mat, from RWG4 as inputs.
%
%   Uses the structure sphere.mat/sphere1.mat to display 
%   radiation intensity distribution over the sphere surface. 
%   The sphere doesn't intersect the radiating object.
%
%   The following parameters need to be specified:
%   
%   Sphere radius (m)
%
%   Copyright 2002 AEMM. Revision 2002/03/11 
%   Chapter 3
% 
% Example 1 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   currents_save = 'C:\currents.mat';
%   efield2_save = 'C:\efield2_save.mat';
%   [Power_and_gain] = efield2_script(rwg2_save, currents_save, ...
%           efield2_save)
% 
% Example 2 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   currents_save = 'C:\currents.mat';
%   efield2_save = 'C:\efield2_save.mat';
%   plot_on = 1;
%   radius = 125;
%   [Power_and_gain] = efield2_script(rwg2_save, currents_save, ...
%           efield2_save,plot_on,radius)
% 
% File Dependencies before this file is run: RWG2 output file, and the
%                                            current output file
%
% File Dependencies within this file: point.m sphere.mat
%

%Load the data
load(rwg2_save);
load(currents_save);
load('sphere.mat');

if ~exist('plot_on', 'var')
    plot_on = 1;
end
if ~exist('radius', 'var')
    radius = 100;
end

p=radius*p;    %sphere radius is 100 m

k=omega/c_;
K=j*k;

for m=1:EdgesTotal
    Point1=Center(:,TrianglePlus(m));
    Point2=Center(:,TriangleMinus(m));
    DipoleCenter(:,m)=0.5*(Point1+Point2);
    DipoleMoment(:,m)=EdgeLength(m)*I(m)*(-Point1+Point2); 
end

TotalPower=0;
%Sphere series
M=length(t);
for m=1:M
    N=t(1:3,m);
    ObservationPoint=1/3*sum(p(:,N),2);
    [E,H]=point(ObservationPoint,eta_,K,DipoleMoment,DipoleCenter);
    ET=sum(E,2); HT=sum(H,2);
    Poynting(:,m)=0.5*real(cross(ET,conj(HT)));
    U(m)=(norm(ObservationPoint))^2*norm(Poynting(:,m));
    Vector1=p(:,N(1))-p(:,N(2));
    Vector2=p(:,N(3))-p(:,N(2));
    Area =0.5*norm(cross(Vector1,Vector2)); 
    TotalPower=TotalPower+norm(Poynting(:,m))*Area;
    %------------------------------
    X(1:3,m)=[p(1,N)]';
    Y(1:3,m)=[p(2,N)]';
    Z(1:3,m)=[p(3,N)]';
end

GainLogarithmic     =10*log10(4*pi*max(U)/TotalPower);
GainLinear          =4*pi*max(U)/TotalPower;

save(efield2_save, 'TotalPower','GainLogarithmic','GainLinear', 'radius');
if plot_on == 0 
    figure
    U=U/norm(U);
    C=repmat(U,3,1);
    h=fill3(X,Y,Z,C);
    colormap gray;
    axis('equal');
    rotate3d on;
end

Power_and_gain = [TotalPower, GainLogarithmic, GainLinear];
