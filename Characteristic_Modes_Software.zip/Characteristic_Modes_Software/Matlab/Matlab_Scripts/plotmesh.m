function plotmesh(u,X,Y,Z)
% Helper function for enginetable demo

% Author(s): Bora Eryilmaz
% Copyright 1995-2011 The MathWorks, Inc.

set(gcf, 'Units', 'norm', 'Position', [0.1 0.1 .8 .4]); 

subplot(1,2,1)
h1 = surfl(Y,X,Z);
shading interp
colormap(gray)
title('Plant Surface using Measured Data')
xlabel('Engine Speed (rpm)');
ylabel(sprintf('Intake Manifold Pressure\n(kPa)'));
zlabel('Volumetric Efficiency');
axis([0 7000 0 100 0.5 1])

subplot(1,2,2)
h2 = surfl(Y,X,u);
shading interp
colormap(gray)
title('Plant Surface using Adaptive Lookup Table (Stair-fit)')
xlabel('Engine Speed (rpm)');
ylabel(sprintf('Intake Manifold Pressure\n(kPa)'));
zlabel('Volumetric Efficiency');
axis([0 7000 0 100 0.5 1])
