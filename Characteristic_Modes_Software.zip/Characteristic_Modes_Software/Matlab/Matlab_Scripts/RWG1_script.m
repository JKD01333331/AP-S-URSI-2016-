function [Run_time] = RWG1_script(Object_location, OBJorSTL, Temp_save, rwg1_save, Mesh_infromation, enable_plot)
% [Run_time] = RWG1_script(Object_location, OBJorSTL, Temp_save, ...
%               rwg1_save, Mesh_infromation, enable_plot)
%
% Main Author: Copyright 2002 AEMM. Revision 2002/03/09 Chapter 2
% Author 2: Buon Kiong Lau
% Author 3: Hui Li
% Author 4: Zachary T Miers
% Function Author: Zachary T Miers (January 14, 2013)
% 
% 
% Inputs:
%   Object_location - The meshed object file
%   OBJorSTL - *.obj or *.stl file format:
%               'obj' or 'obj_m' - imports *.obj files
%               'obj_mm' - imports *.obj files that were exported in mm
%               'stl' or 'stl_m' - imports *.stl files
%               'stl_mm' - imports *.stl files that were exported in mm
%   Temp_save - Temporary directory where files can be saved.
%   rwg1_save - A location and file to save rwg1 file outputs.
%   Mesh_infromation - A flag to turn on mesh charicteristic information.  
%       Default is 0 (mesh information off).
%
% Script Outputs:
%     runtime - The amount of time it took the program to run to completion
% rwg1 save file:
%     Creates the RWG edge element for every inner edge of a triangular
%     structure. The total number of elements is EdgesTotal.
%     Saves the following arrays in specified file:
% 
%     Edge first node number          Edge_(1,1:EdgesTotal)
%     Edge second node number         Edge_(2,1:EdgesTotal)
%     Plus triangle number            TrianglePlus(1:EdgesTotal)
%     Minus triangle number           TriangleMinus(1:EdgesTotal)
%     Edge length                     EdgeLength(1:EdgesTotal)
%     Edge element indicator          EdgeIndicator(1:EdgesTotal)
% 
%     Also outputs areas and midpoints of separate triangles:
%     Triangle area                   Area(1:TrianglesTotal)
%     Triangle center                 Center(1:TrianglesTotal)      
% 
% This script may handle surfaces with T-junctions 
% including monopoles over various metal surfaces and 
% certain metal meshes
% 
% Example 1 of how to run this file:
%
% Object_location = 'C:\Struture.obj';
% Temp_save = 'C:\temp';
% rwg1_save = 'C:\mesh1.mat';
% RWG1_script(Object_location, Temp_save, rwg1_save);
%
% Example 2 of how to run this file:
%
% Object_location = 'C:\Struture.obj';
% Temp_save = 'C:\temp';
% rwg1_save = 'C:\mesh1.mat';
% Mesh_infromation = 1;
% enable_plot = 1;
% RWG1_script(Object_location, Temp_save, rwg1_save, Mesh_infromation, ...
%               enable_plot);
% 
% This script is dependent on: Surface mesh in Obj format
%
% File Dependencies within this file: obj_to_tri_surface.m, plotMesh.m,
%   stlread.m, patchslim.m
%

tic;

if ~exist('Mesh_infromation', 'var')
    Mesh_infromation = 0;
end

if ~exist('enable_plot', 'var')
    enable_plot = 1;
end

if (strcmpi(OBJorSTL,'msh_m'))||(strcmpi(OBJorSTL,'msh'))
    [v, f, n, c, stltitle] = stlread(Object_location); % reads binary stl
    [v, f]=patchslim(v, f); % deletes duplicate entries created by stlread
    faces = f;
    vertices = v;
    
    t = faces.';
    p = vertices.';
elseif strcmpi(OBJorSTL,'msh_mm')
	[v, f, n, c, stltitle] = stlread(Object_location); % reads binary stl
    [v, f]=patchslim(v, f); % deletes duplicate entries created by stlread
    faces = f;
    vertices = v;
    
    t = faces.';
    p = vertices.';
    p = p/1000;
elseif strcmpi(OBJorSTL,'obj_mm')
    obj_to_tri_surface ( Object_location, ...
        [Temp_save '\vertices.txt'], ...
        [Temp_save '\faces.txt'], Mesh_infromation )

    load([Temp_save '\vertices.txt'])
    load([Temp_save '\faces.txt'])

    t = faces.';
    p = vertices.';
    p = p/1000;
elseif (strcmpi(OBJorSTL,'obj_m'))||(strcmpi(OBJorSTL,'obj'))
    obj_to_tri_surface ( Object_location, ...
        [Temp_save '\vertices.txt'], ...
        [Temp_save '\faces.txt'], Mesh_infromation )

    load([Temp_save '\vertices.txt'])
    load([Temp_save '\faces.txt'])

    t = faces.';
    p = vertices.';
else
    warning('Unsupported file type.  See Help file');
    return;
end

% p(1,:) = p(1,:);
% p(2,:) = p(2,:);
% p(3,:) = p(3,:);

p(1,:) = p(1,:) - min(p(1,:));
p(2,:) = p(2,:) - min(p(2,:));
p(3,:) = p(3,:) - min(p(3,:));
% p(1,:) = p(1,:) - (min(p(1,:)) + max(p(1,:)))/2;
% p(2,:) = p(2,:) - (min(p(2,:)) + max(p(2,:)))/2;
% p(3,:) = p(3,:) - (min(p(3,:)) + max(p(3,:)))/2;

if enable_plot == 1
    figure
    plotMesh(p, t);
end

t(4,:)=1;

[s1 s2]=size(p);
if(s1==2)
    p(3,:)=0;   %to convert 2D to 3D
end

%Eliminate unnecessary triangles
Remove=find(t(4,:)>1);   
t(:,Remove)=[];           
TrianglesTotal=length(t);

%Find areas of separate triangles
for m=1:TrianglesTotal
   N=t(1:3,m);
   Vec1=p(:,N(1))-p(:,N(2));
   Vec2=p(:,N(3))-p(:,N(2));
   Area(m) =norm(cross(Vec1,Vec2))/2;
   Center(:,m)=1/3*sum(p(:,N),2);
end

%Find all edge elements "Edge_" with at least two 
%adjacent triangles
Edge_=[];
n=0;
for m=1:TrianglesTotal
    N=t(1:3,m);
    for k=m+1:TrianglesTotal
        M=t(1:3,k);      
        a=1-all([N-M(1) N-M(2) N-M(3)]);
        if(sum(a)==2) %triangles m and k have common edge
            n=n+1;
            Edge_=[Edge_ M(find(a))]; 
            TrianglePlus(n)=m;
            TriangleMinus(n)=k; 
        end; 
    end
end
EdgesTotal=length(Edge_);

%This block is only meaningful for T junctions
%It leaves only two edge elements at a junction 
Edge__=[Edge_(2,:); Edge_(1,:)];
Remove=[];
for m=1:EdgesTotal
    Edge_m=repmat(Edge_(:,m),[1 EdgesTotal]);
    Ind1=any(Edge_  -Edge_m);
    Ind2=any(Edge__ -Edge_m);
    A=find(Ind1.*Ind2==0);
    if(length(A)==3)    %three elements formally exist at a junction 
        Out=find(t(4,TrianglePlus(A))==t(4,TriangleMinus(A)));
        Remove=[Remove A(Out)];
    end
end
Edge_(:,Remove)         =[];
TrianglePlus(Remove)    =[];
TriangleMinus(Remove)   =[];
if Mesh_infromation == 1
    EdgesTotal=length(Edge_)
else
    EdgesTotal=length(Edge_);
end


%All structures of this chapter have EdgeIndicator=2
EdgeIndicator=t(4,TrianglePlus)+t(4,TriangleMinus);

%Find edge length
for m=1:EdgesTotal
   EdgeLength(m)=norm(p(:,Edge_(1,m))-p(:,Edge_(2,m)));
end

%Save result
save(rwg1_save,'p','t','Edge_','TrianglesTotal','EdgesTotal' ...
    ,'TrianglePlus','TriangleMinus','EdgeLength','EdgeIndicator','Area'...
    ,'Center')
        
Run_time = toc;
        
        