function [Run_time] = currents_script(rwg2_save,currents_save,frequency,Select_eigen_mode)
% [Run_time] = currents_script(rwg2_save,currents_save,frequency,...
%                   Select_eigen_mode,Select_eigen_number)
%
% Main Author: Copyright 2002 AEMM. Revision 2002/03/09 Chapter 2
% Author 2: Zachary T Miers
% Author 3: Buon Kiong Lau
% Author 4: Hui Li
% Function Author: Zachary T Miers (January 14, 2013)
% 
% 
% Inputs:
%   rwg2_save - LLocation where rwg2 output file is located.
%   currents_save - Location to save the output currents output file
%   frequency - frequencies to evaluate current at
% Optional input parameters:
%   Select_eigen_mode - 
%       'nothing' - allows you to choose which one while the script is
%           running
%       'min_to_max' - chooses the a specific eigen value, the eigen value 
%           number is choosen by "select_eigen_number"
%   Select_eigen_number - (1) chooses the minimum eigen value, anything
%           greater than (1) chooses subsquently larger eigen values
%           (2) would choose the second smalles eignen value (3) the third
%           and so on.
%
% Script Outputs:
%     runtime - The amount of time it took the program to run to completion
% RWG3-eignemode2 Calculates the impedance matrix using function IMPMET
%   Uses the mesh file from RWG2, mesh2.mat, as an input.
%
%   The following parameters need to be specified prior to 
%   calculations:
%   
%   Frequency (Hz)                  f
%   Dielectric constant (SI)        epsilon_
%   Magnetic permeability (SI)      mu_
%
%   Copyright 2002 AEMM. Revision 2002/03/11 
%   Chapter 2
% 
% Example 1 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   currents_save = 'C:\currents.mat';
%   frequency = 1.5e9;
%   currents_script(rwg2_save,currents_save,frequency)
% 
% Example 2 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   currents_save = 'C:\currents.mat';
%   frequency = 1.5e9;
%   Select_eigen_mode = 'min_to_max';
%   Select_eigen_number = 1;
%   currents_script(rwg2_save,currents_save,frequency,Select_eigen_mode,Select_eigen_number)
% 
% File Dependencies before this file is run: RWG2 output file
%
% File Dependencies within this file: locate.m, impmet.m
%

% Updates 
% August 2013 Zachary Miers
% Basic saves for Correlation
%
% September 2013 Zachary Miers
% Updated tracking code for location of eigen values
%
% November 2014  Zachary Miers
% Further Updats of tracking code for location of eigen values and saves

%Load the data
load(rwg2_save);

if ~exist('Select_eigen_mode', 'var')
    Select_eigen_mode = 'nothing'; % 'min_to_max'
end

%EM parameters (f=3e8 means that f=300 MHz) 
f           =frequency;  
epsilon_    =8.854e-012;
mu_         =1.257e-006;
%Speed of light
c_=1/sqrt(epsilon_*mu_);
%Free-space impedance 
eta_=sqrt(mu_/epsilon_);

%Contemporary variables - introduced to speed up 
%the impedance matrix calculation
omega       =2*pi*f;                                            
k           =omega/c_;
K           =j*k;
Constant1   =mu_/(4*pi);
Constant2   =1/(j*4*pi*omega*epsilon_);
Factor      =1/9;    

FactorA     =Factor*(j*omega*EdgeLength/4)*Constant1;
FactorFi    =Factor*EdgeLength*Constant2;

for m=1:EdgesTotal
    RHO_P(:,:,m)=repmat(RHO_Plus(:,m),[1 9]);   %[3 9 EdgesTotal]
    RHO_M(:,:,m)=repmat(RHO_Minus(:,m),[1 9]);  %[3 9 EdgesTotal]
end
FactorA=FactorA.';
FactorFi=FactorFi.';

%Impedance matrix Z
tic; %start timer

    Z=  impmet( EdgesTotal,TrianglesTotal,...
                EdgeLength,K,...
                Center,Center_,...
                TrianglePlus,TriangleMinus,...
                RHO_P,RHO_M,...
                RHO__Plus,RHO__Minus,...
                FactorA,FactorFi);
    % % make the impedance matrix symetric
    %          Z1=triu(Z);
    %          Z2=Z1+Z1.';
    %          Z3=diag(Z2)./2;
    %          Z4=diag(Z3);
    %          ZZ=Z2-Z4;
    Z1=Z+Z.';
    ZZ=Z1./2;


            R=real(ZZ);
            X=imag(ZZ);
    %         [J(:,:,n),D(:,:,n)]=eig(X(:,:,n),R(:,:,n));
    %         DD(:,n)=diag(D(:,:,n));
    [V, D]=eig(R);%[V, D]=eig(R);
    DD1=diag(D);
    % range the eigenvalue from large to small
    [DD2,IJ]=sort(DD1,1,'descend');
    %range the eigenvedtor accordingly
    for jj=1:EdgesTotal
        V1(:,jj)=V(:,IJ(jj));
    end
    %make the eigen value which is too small zero
    for ii=1:EdgesTotal
        if DD2(ii)<max(DD2)*0.001
            DD2(ii)=0;
        end
    end
        D1=diag(DD2);
    r=rank(D1);
    D11=zeros(EdgesTotal);
    % D11=zeros(9,9,n);
    D11(1:r,1:r)=D1(1:r,1:r);
    % D12(:,:,n)=D1(1:r,r+1:EdgesTotal,n);
    % D21(:,:,n)=D12(:,:,n).';
    % D22(:,:,n)=D1(r1:EdgesTotal,r+1:EdgesTotal,n);
    D2(1:r,1:r)=sqrtm(D11(1:r,1:r));
    A=V1.'*X*V1;
    A11(1:r,1:r)=A(1:r,1:r);
    A12(1:r,1:EdgesTotal-r)=A(1:r,r+1:EdgesTotal);
    A21(1:EdgesTotal-r,1:r)=A12(1:r,1:EdgesTotal-r).';
    A22(1:EdgesTotal-r,1:EdgesTotal-r)=A(r+1:EdgesTotal,r+1:EdgesTotal);
    B(1:r,1:r)=inv(D2(1:r,1:r))*(A11(1:r,1:r)-A12(1:r,1:EdgesTotal-r)*inv(A22(1:EdgesTotal-r,1:EdgesTotal-r))*A21(1:EdgesTotal-r,1:r))*inv(D2(1:r,1:r));
    B1=eig(B(1:r,1:r));
[JJ,EI]=eig(B);
C1=inv(D2)*JJ;
C2=zeros(EdgesTotal,r);
C2(1:r,1:r)=eye(r);
C2(r+1:EdgesTotal,1:r)=-inv(A22)*A21;
I1=V1*C2*C1;

if strcmpi(Select_eigen_mode,'nothing')
    format long g
    numbering_display = transpose(1:1:length(B1));
    B1_with_numbering = [numbering_display, B1];
    display(B1_with_numbering)
    Selected_eigen_mode = input('Which eigenmode current should be saved: ')
    Selected_Eigen_value = B1(Selected_eigen_mode);
    I=I1(:,Selected_eigen_mode);
else
    B1_new = B1;
    while Select_eigen_mode > 1
        [Y,I] = sort(B1_new);
        
        delete_row_number = find(abs(B1_new) == min(abs(B1_new)));
        if delete_row_number == 1
            B1_new = B1_new(2:end);
        elseif delete_row_number == length(B1_new)
             B1_new = B1_new(1:end-1);
        else
            B1_new = [B1_new(1:delete_row_number-1);...
                B1_new(delete_row_number+1:end)];
        end
        Select_eigen_mode = Select_eigen_mode - 1;
    end

    Selected_eigen_mode = find(abs(B1) == min(abs(B1_new)));
    Selected_eigen_mode
    Selected_Eigen_value = B1(Selected_eigen_mode);
    I=I1(:,Selected_eigen_mode);
end

%Save result
% FileName='impedance.mat'; 
% save(FileName, 'f','omega','mu_','epsilon_','c_', 'eta_','Z');  

save(currents_save, 'f','omega','mu_','epsilon_','c_', 'eta_','I',...
    'Selected_eigen_mode','Selected_Eigen_value');

Run_time = toc; %elapsed time