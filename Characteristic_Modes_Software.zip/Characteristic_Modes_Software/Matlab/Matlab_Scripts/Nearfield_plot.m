function [Run_time] = Nearfield_plot(nearfields_save, Nearfield_views, ...
    aspect_ratio, set_xyz_axis, set_z_vector)
% [Run_time] = Nearfield_plot(nearfields_save, Nearfield_views, ...
%     aspect_ratio, set_xyz_axis, set_z_vector)
%
% Main Author: Zachary T Miers (January 17, 2013)
% Function Author: Zachary T Miers (January 17, 2013)
%
% Inputs:
%   nearfields_save - Location and file created by Nearfields_script.m
% 
% Optional inputs:
%   Nearfield_views - plot specific views: all plots on - 'all', magnitude
%       - 'mag', all H plots - 'H', all E plots - 'E', many more are
%       avalible see help Nearfield_view_lookup
%   aspect_ratio - input required aspect ratio in [x y z] form, for auto
%       aspect ratio 'off' or 'auto' will set default values
%   set_xyz_axis - Set the xyz axis on plots [x y z], To automatically set
%       the axis use 'auto'
%
% Outputs:
% 	Runtime: time it takes for the program to run
% 
% Example 1 of how to run this file:
%   nearfields_save = 'C:\nearfields.mat';
%   Run_time = Nearfield_plot(nearfields_save);
% 
% Example 2 of how to run this file:
%   nearfields_save = 'C:\nearfields.mat';
%   Nearfield_views = 'all';
%	aspect_ratio = 'auto';
%	set_xyz_axis = [0 0.12 0 0.06 0 -30];
%   Run_time = Nearfield_plot(nearfields_save, Nearfield_views, aspect_ratio, ...
%       set_xyz_axis);
% 
% File Dependencies before this file is run: Nearfields_script.m
% 
% File Dependencies within this file: Nearfield_view_lookup
%

% Update Jan 20, 2015 addeded set_z_vector to scale 'Z'

tic;

if ~exist('Nearfield_views', 'var')
    Nearfield_views = 'all';
end
if ~exist('aspect_ratio', 'var')
    aspect_ratio = 'off';
end
if ~exist('set_xyz_axis', 'var')
    set_xyz_axis = 'auto';
end
if ~exist('set_z_vector', 'var')
    set_z_vector = 0;
end


%Load the data
load(nearfields_save);

Nearfield_views = Nearfield_view_lookup(Nearfield_views); % locates the
                    % plots that were requested

[pp,qq]=meshgrid(p*1000,q*1000);

% index points of plot
Em = 1;
Hm = 2;
Hx = 3;
Hy = 4;
Hz = 5;
Ex = 6;
Ey = 7;
Ez = 8;

% plot fields
if Nearfield_views(Em) == 1 % Magnitude Plot of E-field
    figure; % apply_ppt_format
    mesh(pp,qq,EEdB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(mm)','FontSize',17);
    ylabel('(mm)','FontSize',17);
    zlabel('E (dB)','FontSize',17);
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        if set_z_vector == 1
            xyz_auto = daspect;
            aspect_ratio(3) = aspect_ratio(1)*(xyz_auto(3)/xyz_auto(1))*2;
        end
        
        daspect(aspect_ratio);
        axis equal;
    end
    set(gca,'FontSize',17) %
end

if Nearfield_views(Hm) == 1 % Magnitude Plot of H-field
    figure; % apply_ppt_format
    mesh(pp,qq,HHdB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(mm)','FontSize',17);
    ylabel('(mm)','FontSize',17);
    zlabel('H (dB)','FontSize',17);
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        if set_z_vector == 1
            xyz_auto = daspect;
             aspect_ratio(3) = aspect_ratio(1)*(xyz_auto(3)/xyz_auto(1))*2;
        end
            
        daspect(aspect_ratio);
        axis equal;
    end
    set(gca,'FontSize',17) %
end

% if Nearfield_views(Poy) == 1 % Plot of Poynting vector
%     % mesh(pp,qq,poynting.');
%     % if strcmpi(set_xyz_axis,'auto') == 0
%     %     axis(set_xyz_axis)
%     % end
%     % Xlabel('(mm)');
%     % Ylabel('(mm)');
%     % Zlabel('Poynting');
%     % if (strcmpi(aspect_ratio,'off') == 0)||(strcmpi(aspect_ratio,'auto') == 0)
%     %     daspect(aspect_ratio);
%     %      axis equal;
%     % end
% end

if Nearfield_views(Hx) == 1 % Plot of H-field x component
    figure; ; % apply_ppt_format
    mesh(pp,qq,HHxdB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(mm)','FontSize',17);
    ylabel('(mm)','FontSize',17);
    zlabel('Hx (dB)','FontSize',17);
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        if set_z_vector == 1
            xyz_auto = daspect;
            aspect_ratio(3) = aspect_ratio(1)*(xyz_auto(3)/xyz_auto(1))*2;
        end
        
        daspect(aspect_ratio);
        axis equal;
    end
    set(gca,'FontSize',17) %
end

if Nearfield_views(Hy) == 1 % Plot of H-field y component
    figure; % apply_ppt_format
    mesh(pp,qq,HHydB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(mm)','FontSize',17);
    ylabel('(mm)','FontSize',17);
    zlabel('Hy (dB)','FontSize',17);
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        if set_z_vector == 1
            xyz_auto = daspect;
            aspect_ratio(3) = aspect_ratio(1)*(xyz_auto(3)/xyz_auto(1))*2;
        end
        
        daspect(aspect_ratio);
        axis equal;
    end
    set(gca,'FontSize',17) %
end

if Nearfield_views(Hz) == 1 % Plot of H-field z component
    figure; % apply_ppt_format
    mesh(pp,qq,HHzdB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(mm)','FontSize',17);
    ylabel('(mm)','FontSize',17);
    zlabel('Hz (dB)','FontSize',17);
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        if set_z_vector == 1
            xyz_auto = daspect;
            aspect_ratio(3) = aspect_ratio(1)*(xyz_auto(3)/xyz_auto(1))*2;
        end
        
        daspect(aspect_ratio);
        axis equal;
    end
    set(gca,'FontSize',17) %
end

if Nearfield_views(Ex) == 1 % Plot of E-field x component
    figure; % apply_ppt_format
    mesh(pp,qq,EExdB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(mm)','FontSize',17);
    ylabel('(mm)','FontSize',17);
    zlabel('Ex (dB)','FontSize',17);
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        if set_z_vector == 1
            xyz_auto = daspect;
            aspect_ratio(3) = aspect_ratio(1)*(xyz_auto(3)/xyz_auto(1))*2;
        end
        
        daspect(aspect_ratio);
        axis equal;
    end
    set(gca,'FontSize',17) %
end

if Nearfield_views(Ey) == 1 % Plot of E-field y component
    figure; % apply_ppt_format
    mesh(pp,qq,EEydB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(mm)','FontSize',17);
    ylabel('(mm)','FontSize',17);
    zlabel('Ey (dB)','FontSize',17);
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        if set_z_vector == 1
            xyz_auto = daspect;
            aspect_ratio(3) = aspect_ratio(1)*(xyz_auto(3)/xyz_auto(1))*2;
        end
        
        daspect(aspect_ratio);
        axis equal;
    end
    set(gca,'FontSize',17) %
end

if Nearfield_views(Ez) == 1 % Plot of E-field z component
    figure; % apply_ppt_format
    mesh(pp,qq,EEzdB.');
    axis tight;
    if strcmpi(set_xyz_axis,'auto') == 0
        axis(set_xyz_axis)
    end
    xlabel('(mm)','FontSize',17);
    ylabel('(mm)','FontSize',17);
    zlabel('Ez (dB)','FontSize',17);
    if (strcmpi(aspect_ratio,'off') == 0)&&(strcmpi(aspect_ratio,'auto') == 0)
        if set_z_vector == 1
            xyz_auto = daspect;
            aspect_ratio(3) = aspect_ratio(1)*(xyz_auto(3)/xyz_auto(1))*2;
        end
        
        daspect(aspect_ratio);
        axis equal;
    end
    set(gca,'FontSize',17) %
end

Run_time = toc;
