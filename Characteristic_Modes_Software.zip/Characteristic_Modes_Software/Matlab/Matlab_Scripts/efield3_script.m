function [GainLogarithmic] = efield3_script(rwg2_save, currents_save, ...
    efield2_save, plot_axis,Linear_or_dB, setaxis, setlinecolor, ...
    setaxis_tic, setfontsize)
% [Power_and_gain] = efield2_script(rwg2_save, currents_save, ...
%     efield2_save, radius)
%
% Main Author: Copyright 2002 AEMM. Revision 2002/03/09 Chapter 2
% Author 2: Buon Kiong Lau
% Author 3: Hui Li
% Author 4: Zachary T Miers
% Function Author: Zachary T Miers (January 17, 2013)
%
% Inputs:
%   rwg2_save - Location where rwg2 output file is located.
%   currents_save - Location where currents output file is located.
%   efield2_save - Location where efield2 output file is located.
%   plot_axis - principle plane axis' - 'xy', 'xz', 'yz'
% 
% Optional inputs:
%   setaxis - set figure scale i.e. from -10dB to 0dB = [-10 0] 
%   setlinecolor - see help mmpolar for all options
%   setaxis_tic - sets the size degree spacing
%   setfontsize - sets the font size of the figure
%
% Outputs:
% 	GainLogarithmic - maximum gain of plot
% 
%EFIELD3 2D Radiation patterns
%   Uses the mesh file from RWG2, mesh2.mat, and
%   the file containing surface current coefficients,
%   current.mat, from RWG4 as inputs.
%
%   Additionally uses the value of TotalPower saved 
%   in file gainpower.mat (script efield2.m)
%
%   The following parameters need to be specified:
%   
%   Radius of the circle (m)            R
%   Plane of the circle:                [x y 0] or 
%                                       [x 0 z] or 
%                                       [0 y z] 
%   Number of discretization points per 
%   pattern                             NumPoints
%
%   Copyright 2002 AEMM. Revision 2002/03/11 
%   Chapter 3
% 
% Example 1 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   currents_save = 'C:\currents.mat';
%   efield2_save = 'C:\efield2_save.mat';
%   plot_axis = 'yz';
%   efield3_script(rwg2_save, currents_save, efield2_save, plot_axis);
% 
% Example 2 of how to run this file:
%   rwg2_save = 'C:\mesh2.mat';
%   currents_save = 'C:\currents.mat';
%   efield2_save = 'C:\efield2_save.mat';
%   plot_axis = 'yz';
%   setaxis = [-10 0];
%   setlinecolor = 'b--';
%   setaxis_tic = 30;
%   setfontsize = 15;
%   efield3_script(rwg2_save, currents_save, efield2_save, plot_axis, ...
%       setaxis, setlinecolor,setaxis_tic,setfontsize);
% 
% File Dependencies before this file is run: RWG2 output file, and the
%           current output file, and efields2 output file
%
% File Dependencies within this file: mmpolar.m point.m
%

tic;

if ~exist('Linear_or_dB', 'var')
    Linear_or_dB = 0;
end

if ~exist('setaxis', 'var')
    setaxis = 'auto';
end
if ~exist('setlinecolor', 'var')
    setlinecolor = 'r--';
end
if strcmpi(setlinecolor,'auto') == 1
    setlinecolor = 'r--';
end
if ~exist('setaxis_tic', 'var')
    setaxis_tic = 'auto';
end
if ~exist('setfontsize', 'var')
    setfontsize = 'auto';
end
if strcmpi(setfontsize,'auto') == 1
    setfontsize = 11;
end


%Load the data
load(rwg2_save);
load(currents_save);
load(efield2_save);

k=omega/c_;
K=j*k;

for m=1:EdgesTotal
    Point1=Center(:,TrianglePlus(m));
    Point2=Center(:,TriangleMinus(m));
    DipoleCenter(:,m)=0.5*(Point1+Point2);
    DipoleMoment(:,m)=EdgeLength(m)*I(m)*(-Point1+Point2); 
end

NumPoints=101;
R=radius; %pattern in m
for ii=1:NumPoints+1
   phi(ii)=(ii-1)*pi/(NumPoints/2);
%    x=R*cos(phi(ii));   %always z but x for xy plane
%    z=R*sin(phi(ii));  %z=R*cos(phi(ii));
%    y=R*sin(phi(ii));   %x or y for z plane
   %locate which axis to plot from function inputs
   if strcmpi(plot_axis,'xy') == 1
       x=R*cos(phi(ii));   %always z but x for xy plane
       y=R*sin(phi(ii));   %x or y for z plane
       ObservationPoint=[x y 0]';
   elseif strcmpi(plot_axis,'xz') == 1
       x=R*cos(phi(ii));   %always z but x for xy plane
       z=R*sin(phi(ii));  %z=R*cos(phi(ii));
       ObservationPoint=[x 0 z]';
   elseif strcmpi(plot_axis,'yz') == 1
       y=R*cos(phi(ii));   %x or y for z plane
       z=R*sin(phi(ii));  %z=R*cos(phi(ii));
       ObservationPoint=[0 y z]';
   else
       warning('That is not a valid principle plane... Exiting process');
       return;
   end
   [E,H]=point(ObservationPoint,eta_,K,DipoleMoment,DipoleCenter);
   ET=sum(E,2); HT=sum(H,2);
   Poynting=0.5*real(cross(ET,conj(HT)));
   W(ii)=norm(Poynting);
   U(ii)=(norm(ObservationPoint))^2*W(ii);
end

Polar_=10*log10(4*pi*U/TotalPower);

GainLogarithmic=max(Polar_); %gain for the particular pattern!
figure;
%This is the standard Matlab polar plot
OFFSET=40; polar(phi,max(Polar_+OFFSET,0)); grid on;
Title=strcat('Offset= ', num2str(OFFSET), ' dB');
title(Title);

%This is Balanis' relative power: 
Polar=10*log10(U/max(U)); OFFSET=40; 
polar(phi,Polar+OFFSET); 
grid on;

if Linear_or_dB == 1
    Polar = db2pow(Polar);
end

if (strcmpi(setaxis,'auto') == 1)&&(strcmpi(setaxis_tic,'auto') == 1)
    mmpolar(phi,Polar',setlinecolor,'Fontsize',11);
    
elseif (strcmpi(setaxis,'auto') == 0)&&(strcmpi(setaxis_tic,'auto') == 1)
    mmpolar(phi,Polar',setlinecolor,'Fontsize',setfontsize,'rlim',setaxis);
    
elseif (strcmpi(setaxis,'auto') == 1)&&(strcmpi(setaxis_tic,'auto') == 0)
    mmpolar(phi,Polar', setlinecolor, 'Fontsize', setfontsize, ...
        'TTickDelta', setaxis_tic); %set {degrees} | radians
    
elseif (strcmpi(setaxis,'auto') == 0)&&(strcmpi(setaxis_tic,'auto') == 0)
    mmpolar(phi,Polar', setlinecolor, 'Fontsize', setfontsize, ...
        'rlim', setaxis, 'TTickDelta', setaxis_tic);
end

if strcmpi(plot_axis,'xy') == 1
    text(0.75,0.9,'XY Axis','fontweight','bold','fontsize',13)
    text(.1,1.078,'Y','fontweight','bold','fontsize',13); % Y Axis (Top)
    text(1.15,0,'X','fontweight','bold','fontsize',13); % X Axis (Right)
    text(1.1,-1,sprintf('%5.2f dB',GainLogarithmic)); % dB Power
    text(1.1,-1.1,sprintf('%5.2f linear',db2pow(GainLogarithmic))); % Power
elseif strcmpi(plot_axis,'xz') == 1
    text(0.75,0.9,'XZ Axis','fontweight','bold','fontsize',13)
    text(.1,1.078,'Z','fontweight','bold','fontsize',13); % Z Axis (Top)
    text(1.15,0,'X','fontweight','bold','fontsize',13); % X Axis (Right)
    text(1.1,-1,sprintf('%5.2f dB',GainLogarithmic)); % dB Power
    text(1.1,-1.1,sprintf('%5.2f linear',db2pow(GainLogarithmic))); % Power
elseif strcmpi(plot_axis,'yz') == 1
    text(0.75,0.9,'YZ Axis','fontweight','bold','fontsize',13)
    text(.1,1.078,'Z','fontweight','bold','fontsize',13); % Z Axis (Top)
    text(1.15,0,'Y','fontweight','bold','fontsize',13); % Y Axis (Right)
    text(1.1,-1,sprintf('%5.2f dB',GainLogarithmic)); % dB Power
    text(1.1,-1.1,sprintf('%5.2f linear',db2pow(GainLogarithmic))); % Power
end

