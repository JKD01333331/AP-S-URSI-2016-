function [index, value, error] = locate(A, x, nowarn)
% [index, value] = locate(A, x, nowarn)
%
% Author: James L. McDonald
% Second Author: Zachary Miers
%
% Purpose: Finds the index of the closest value of x in A. If multiple
% values match, the first encoutered will be returned.  If x is also a
% vector, the program will find the index and value in A closest to each
% element in x.
%
% Inputs:
%   A - The vector in which we should search.
%   x - The value(s) for which we are searching.
%   nowarn - A flag to turn off warnings.  Default is 0 (warnings on).
%
% Outputs:
%   index - the index/indices of A where x is closest
%   value - the actual value(s) in A closest to x
%   error - the error between the desired and returned value:
%           value + error = x

% $Log5: M:\Matlab_Analysis_Tools\QVCS\Utilities\locate.n $
%  
%    Auto-added
%  
%  Revision 1.3  by: alalezari  Rev date: Mon 07/09/2007 17:56:32 UTC
%    Added a new output that allows the user to have access to the error in
%    the returned values, relative to the desired values.
%  
%  Revision 1.2  by: zmiers  Rev date: Tue 08/29/2006 17:25:26 UTC
%    Modified the code to return NaN if the value being searched for is also
%    NaN.  Previously, the code would default to the first index, having
%    not found NaN in the data.
%  
%  Revision 1.1  by: jmcdonald  Rev date: Tue 08/22/2006 21:06:58 UTC
%    Changed the size of the output vectors such that they are the same as
%    the input vector.
%  
%  Revision 1.0  by: jmcdonald  Rev date: Mon 06/19/2006 20:28:03 UTC
%    Initial Revision
%  
%  $Endlog$

if ~exist('nowarn', 'var')
    nowarn = 0;
end
if nowarn
    warning off MATLAB:NotLocate
end

% Initialize variables
value = NaN(size(x));
index = NaN(size(x));
error = NaN(size(x));

for i = 1:length(x)
    % Check to see if the value can be in the set of data
    if isnan(x(i))
        value(i) = NaN;
        index(i) = NaN;
        error(i) = NaN;
    elseif x(i) > max(A)
        [value(i), index(i)] = max(A);
        error(i) = x(i)-value(i);
        warning('MATLAB:NotLocate', '%f is not contained in the vector.', x(i))
    elseif x(i) < min(A)
        [value(i), index(i)] = min(A);
        error(i) = x(i)-value(i);
        warning('MATLAB:NotLocate', '%f is not contained in the vector.', x(i))
    else
        % Find the closest value
        [trash, index(i)] = min(abs(A-x(i)));
        value(i) = A(index(i));
        error(i) = x(i)-value(i);
    end
end